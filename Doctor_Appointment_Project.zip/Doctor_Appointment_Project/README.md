# MediCare Doctor Appointment Website — Beginner Setup & Presentation Guide

## 1. What this project is
This is a first-year B.Sc. Computer Science front-end project made using ONLY HTML5 and CSS3. It demonstrates a responsive doctor appointment website with navigation, doctors, services, an appointment form, required-field validation, and a CSS-only appointment confirmation popup.

IMPORTANT: The confirmation is a front-end demonstration. HTML/CSS cannot save an appointment to a database. A real booking system would need JavaScript and/or a backend/database.

## 2. Files in this package
- index.html — all webpage structure/content.
- style.css — all styling, responsive design, hover effects, and popup styling.
- README.md — this beginner guide.
- Doctor_Appointment_Project_Presentation.pptx — starter presentation.

Keep index.html and style.css in the SAME folder.

## 3. Software required
### A. Visual Studio Code (VS Code)
VS Code is the editor used to open and edit the project.
1. Open a web browser.
2. Search for “Visual Studio Code download”.
3. Open the official Microsoft Visual Studio Code website.
4. Download the installer for your operating system (Windows/macOS).
5. Run the installer.
6. On Windows, leave the normal/default installation choices selected. If offered, enabling “Add to PATH” and “Open with Code” is useful.
7. Finish installation and open Visual Studio Code.

### B. Web browser
Use Google Chrome or Microsoft Edge. No special browser extension is required.

### C. VS Code extension: Live Server
1. Open VS Code.
2. On the far-left sidebar, click the Extensions icon (four small blocks), OR press Ctrl+Shift+X on Windows.
3. Search for: Live Server
4. Find “Live Server” by Ritwick Dey.
5. Click Install.
6. Wait until the button changes to indicate it is installed.

No Python, Java, Node.js, XAMPP, PHP, MySQL, WordPress, or other software is needed for this HTML/CSS project.

## 4. Extract the ZIP
1. Save Doctor_Appointment_Project.zip to the computer.
2. On Windows, right-click the ZIP and choose “Extract All…”.
3. Choose a location such as Desktop.
4. Click Extract.
5. Open the extracted Doctor_Appointment_Project folder.
6. Confirm that index.html and style.css are present.

DO NOT run the website directly from inside the ZIP. Extract it first.

## 5. Open the project correctly in VS Code
Method 1:
1. Open VS Code.
2. Click File > Open Folder.
3. Select Doctor_Appointment_Project.
4. Click Select Folder/Open.
5. If VS Code asks whether you trust the folder, choose the appropriate trust option for this project.

The left Explorer panel should show index.html, style.css, README.md, and the presentation.

## 6. Start the website with Live Server
1. In VS Code Explorer, click index.html.
2. Save the file if needed: Ctrl+S on Windows or Cmd+S on Mac.
3. Right-click anywhere inside index.html.
4. Click “Open with Live Server”.
5. A browser should open automatically.
6. The address may look similar to http://127.0.0.1:5500/index.html or http://localhost:5500/index.html.
7. Leave VS Code and the browser open while demonstrating the project.

Alternative: If “Go Live” appears at the bottom-right of VS Code, open index.html and click “Go Live”.

## 7. How to refresh Live Server — very important
Normally Live Server refreshes automatically whenever a file is SAVED.

After editing index.html or style.css:
1. Press Ctrl+S (Windows) or Cmd+S (Mac).
2. Wait a moment.
3. Look at the browser. It should automatically refresh.

If the browser does NOT refresh:
1. Click the browser window.
2. Press Ctrl+R on Windows or Cmd+R on Mac; OR click the browser Refresh/Reload arrow.

If changes still do not appear:
1. Make sure the correct file was saved.
2. Check that index.html contains: <link rel="stylesheet" href="style.css">
3. Check that index.html and style.css are in the same folder.
4. Try Ctrl+Shift+R in Chrome/Edge on Windows for a harder refresh.
5. Restart Live Server using the steps below.

## 8. How to restart Live Server
If Live Server stops or becomes stuck:
1. Return to VS Code.
2. Look at the bottom status bar. If Live Server is running, it may show a port such as “Port: 5500”.
3. Click the Live Server/port status to stop it, if available.
4. Open index.html again.
5. Right-click inside the file.
6. Choose “Open with Live Server”.
7. The browser should reopen/reload.

If the bottom-right says “Go Live”, Live Server is currently stopped. Click “Go Live”.

## 9. How to test the website before presenting
### Navigation test
Click Home, Doctors, Services, Appointment, and Contact. The page should scroll to the matching section.

### Appointment test
1. Enter a patient name.
2. Choose a doctor.
3. Choose an appointment date.
4. Choose a time.
5. Enter a valid-looking email address.
6. Enter a phone number.
7. Click Confirm Appointment.
8. A popup should say “Appointment Booked!” and “Booking Confirmed”.
9. Click Done to close the popup and return to the top.

### Required-field validation test
Click Confirm Appointment without completing the form. The browser should ask for required information instead of showing the confirmation.

### Responsive design test
1. Make the browser window narrower and wider.
2. Notice that the layout changes for smaller screens.
3. Optional: press F12 in Chrome/Edge, click the phone/tablet device icon, and test a mobile size.
4. Press F12 again to close Developer Tools.

## 10. How the project works
HTML = structure and content. Examples: headings, navigation, form fields, doctor cards, footer.
CSS = appearance and layout. Examples: colors, spacing, cards, grid, hover effects, mobile responsiveness, popup.

Important HTML elements:
- <!DOCTYPE html> — identifies an HTML5 document.
- <head> — page information/settings.
- <title> — browser tab title.
- <link> — connects style.css.
- <body> — visible webpage content.
- <header> and <nav> — navigation area.
- <main> and <section> — main content sections.
- <form> — appointment form.
- <input> — user data fields.
- <select> — dropdown lists.
- <footer> — bottom section.

Important CSS concepts:
- class selectors such as .doctor-card style groups of elements.
- display:flex creates flexible row/column layouts.
- display:grid creates grid layouts.
- :hover changes appearance when the mouse is over an element.
- @media rules change layouts at smaller screen widths.
- :target is used to display the booking confirmation popup without JavaScript.

## 11. How the confirmation popup works without JavaScript
The form uses action="#booking-success". When the form passes browser validation and is submitted, the URL targets the element with id="booking-success".

CSS contains .popup:target, which makes the hidden popup visible. Clicking Done links back to #home, so the popup is no longer the target and becomes hidden again.

This is useful to mention during the presentation because it demonstrates a CSS pseudo-class.

## 12. What to say during the presentation
Suggested introduction:
“My project is a Doctor Appointment Booking webpage developed using HTML5 and CSS3. The objective was to create a responsive and user-friendly front-end interface where patients can view doctors, medical services, and submit appointment information. HTML was used for the structure and content, while CSS was used for styling, layout, responsiveness, visual effects, and the confirmation popup.”

Suggested demonstration order:
1. Show the navigation bar and homepage.
2. Show the appointment form.
3. Show the doctor cards.
4. Show the healthcare services.
5. Resize the browser to demonstrate responsive design.
6. Complete the appointment form.
7. Click Confirm Appointment and show the popup.
8. Explain that it is a front-end demonstration only.

## 13. Common viva/presentation questions
Q: What is HTML?
A: HTML stands for HyperText Markup Language. It provides the structure and content of a webpage.

Q: What is CSS?
A: CSS stands for Cascading Style Sheets. It controls the appearance and layout of HTML elements.

Q: Why are HTML and CSS in separate files?
A: Separating structure from styling makes the project easier to organize, maintain, and edit.

Q: What is responsive design?
A: Responsive design allows the webpage layout to adapt to different screen sizes such as desktop, tablet, and mobile.

Q: What is a CSS media query?
A: A media query applies different CSS rules depending on conditions such as screen width.

Q: Does this website really save appointments?
A: No. The assignment uses only HTML and CSS, so this is a front-end demonstration. Saving appointments permanently would require additional programming and a backend/database.

Q: Did you use JavaScript for the popup?
A: No. The popup uses the CSS :target pseudo-class and an HTML anchor target.

Q: What does required do in a form field?
A: It tells the browser that the field must be completed before the form can be submitted.

Q: What is the purpose of Live Server?
A: It runs the local webpage in a browser and automatically reloads it when saved files change.

## 14. Safe edits before submission
The student should personalize the project rather than blindly presenting it. Safe changes include:
- Clinic name “MediCare”.
- Doctor names and specialties.
- Contact address/phone/email.
- Opening hours.
- Text descriptions.

After EVERY edit: save with Ctrl+S/Cmd+S and verify the browser.

## 15. Do not do these things just before presentation
- Do not rename index.html or style.css unless you also understand/update the references.
- Do not move style.css to another folder.
- Do not delete closing tags randomly.
- Do not add JavaScript if the assignment says HTML/CSS only.
- Do not claim the appointment is stored in a database.
- Do not present without testing the popup first.

## 16. Presentation-day checklist
Before leaving/home or before class:
[ ] Laptop charged and charger packed.
[ ] Project ZIP and extracted project folder available.
[ ] Backup copy on USB/cloud/email if permitted.
[ ] VS Code installed.
[ ] Live Server installed.
[ ] Browser installed.
[ ] index.html opens successfully with Live Server.
[ ] style.css loads correctly.
[ ] Navigation links work.
[ ] Appointment form validates required fields.
[ ] Confirmation popup appears.
[ ] Done button closes popup.
[ ] Presentation opens in PowerPoint/compatible software.
[ ] Student has practiced the 1-minute introduction.

## 17. If Live Server cannot be installed at college
For an emergency preview, double-click index.html to open it directly in a browser. Most of the page will still work because this project is plain HTML/CSS. Live Server is preferable during development because it auto-refreshes.

## 18. Final project title
Design and Development of a Responsive Doctor Appointment Booking Webpage Using HTML and CSS
